import nodemailer from "npm:nodemailer@6.9.14";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const j=(o:unknown,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async req=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  try{
    const{to,subject,filename,pdfBase64}=await req.json();
    if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)||!pdfBase64||pdfBase64.length>7e6)throw new Error("requête invalide");
    const user=Deno.env.get("GMAIL_USER"),pass=Deno.env.get("GMAIL_APP_PASSWORD");
    const t=nodemailer.createTransport({host:"smtp.gmail.com",port:465,secure:true,auth:{user,pass}});
    await t.sendMail({from:user,to,subject:String(subject||"Carte mentale").slice(0,150),
      text:"Veuillez trouver ci-joint la carte mentale au format PDF.",
      attachments:[{filename:filename||"carte-mentale.pdf",content:pdfBase64,encoding:"base64"}]});
    return j({ok:true});
  }catch(e){return j({ok:false,error:String(e)},400)}
});
