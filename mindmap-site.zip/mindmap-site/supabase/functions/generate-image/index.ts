// Exemple avec l'API OpenAI ; remplacez l'appel par celui de votre fournisseur si besoin.
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const j=(o:unknown,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async req=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  try{
    const{prompt}=await req.json();
    if(!prompt||String(prompt).length>1000)throw new Error("prompt invalide");
    const r=await fetch("https://api.openai.com/v1/images/generations",{method:"POST",
      headers:{"Content-Type":"application/json",Authorization:"Bearer "+Deno.env.get("OPENAI_API_KEY")},
      body:JSON.stringify({model:"gpt-image-1",prompt:String(prompt),size:"1024x1024"})});
    const d=await r.json();
    if(!r.ok)throw new Error(d.error?.message||"erreur fournisseur");
    return j({b64:d.data[0].b64_json});
  }catch(e){return j({error:String(e)},400)}
});
